package utils;

public enum DurataAbb {
	SETTIMANALI,
	MENSILI,
	GIORNALIERO
}
