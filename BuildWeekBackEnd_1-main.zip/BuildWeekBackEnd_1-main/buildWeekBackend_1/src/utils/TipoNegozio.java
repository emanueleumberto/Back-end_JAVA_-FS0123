package utils;

public enum TipoNegozio {
	BAR,
	EDICOLA,
	TABACCHI
}
